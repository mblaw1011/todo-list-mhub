import { MuiTypography } from "./components/MuiTypography";
import { MuiButton } from "./components/MuiButton";
import { MuiLayout } from "./components/MuiLayout";

function App() {
  return (
    <>
      <MuiTypography />
      <MuiButton />
      <MuiLayout />
    </>
  );
}

export default App;
